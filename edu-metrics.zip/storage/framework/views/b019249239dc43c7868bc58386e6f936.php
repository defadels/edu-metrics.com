

<?php $__env->startSection('title', 'Beranda'); ?>

<?php $__env->startSection('content'); ?>
<!-- Hero Section -->
<div class="bg-gradient-to-r from-blue-600 to-blue-800 text-white">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div class="text-center">
            <h1 class="text-4xl font-bold mb-4">Sistem Survey Edu Metrics</h1>
            <p class="text-xl mb-8">Platform untuk mengumpulkan feedback dan evaluasi melalui survey</p>
            <a href="<?php echo e(route('surveys.index')); ?>" class="inline-block bg-white text-blue-600 px-6 py-3 rounded-lg font-semibold hover:bg-gray-100 transition">
                Lihat Survey Tersedia
            </a>
        </div>
    </div>
</div>

<!-- Stats Section -->
<div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
    <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div class="bg-white rounded-lg shadow p-6 text-center">
            <div class="text-3xl font-bold text-blue-600 mb-2"><?php echo e($stats['total_surveys']); ?></div>
            <div class="text-gray-600">Total Survey</div>
        </div>
        <div class="bg-white rounded-lg shadow p-6 text-center">
            <div class="text-3xl font-bold text-green-600 mb-2"><?php echo e($stats['active_surveys']); ?></div>
            <div class="text-gray-600">Survey Aktif</div>
        </div>
        <div class="bg-white rounded-lg shadow p-6 text-center">
            <div class="text-3xl font-bold text-purple-600 mb-2"><?php echo e($stats['categories']); ?></div>
            <div class="text-gray-600">Kategori</div>
        </div>
    </div>
</div>

<!-- Active Surveys Section -->
<div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
    <div class="mb-8">
        <h2 class="text-3xl font-bold text-gray-900 mb-2">Survey Terbaru</h2>
        <p class="text-gray-600">Ikuti survey yang sedang berlangsung</p>
    </div>

    <?php if($activeSurveys->count() > 0): ?>
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <?php $__currentLoopData = $activeSurveys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $survey): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="bg-white rounded-lg shadow hover:shadow-lg transition overflow-hidden">
                    <div class="p-6">
                        <div class="flex items-center justify-between mb-4">
                            <span class="px-3 py-1 text-xs font-semibold rounded-full bg-blue-100 text-blue-800">
                                <?php echo e($survey->category->name); ?>

                            </span>
                            <?php if($survey->is_anonymous): ?>
                                <span class="px-3 py-1 text-xs font-semibold rounded-full bg-gray-100 text-gray-800">
                                    Anonim
                                </span>
                            <?php endif; ?>
                        </div>
                        <h3 class="text-xl font-semibold text-gray-900 mb-2"><?php echo e($survey->title); ?></h3>
                        <?php if($survey->description): ?>
                            <p class="text-gray-600 mb-4 line-clamp-2"><?php echo e(Str::limit($survey->description, 100)); ?></p>
                        <?php endif; ?>
                        <div class="flex items-center justify-between text-sm text-gray-500 mb-4">
                            <span>Berakhir: <?php echo e($survey->end_date->format('d M Y')); ?></span>
                        </div>
                        <a href="<?php echo e(route('surveys.show', $survey)); ?>" class="block w-full text-center bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition">
                            Lihat Detail
                        </a>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php else: ?>
        <div class="text-center py-12">
            <p class="text-gray-500">Belum ada survey yang tersedia saat ini.</p>
        </div>
    <?php endif; ?>

    <div class="mt-8 text-center">
        <a href="<?php echo e(route('surveys.index')); ?>" class="inline-block bg-gray-200 text-gray-800 px-6 py-3 rounded-lg font-semibold hover:bg-gray-300 transition">
            Lihat Semua Survey
        </a>
    </div>
</div>

<!-- Categories Section -->
<?php if($categories->count() > 0): ?>
    <div class="bg-gray-100 py-12">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="mb-8">
                <h2 class="text-3xl font-bold text-gray-900 mb-2">Kategori Survey</h2>
                <p class="text-gray-600">Jelajahi survey berdasarkan kategori</p>
            </div>
            <div class="grid grid-cols-2 md:grid-cols-4 gap-4">
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="bg-white rounded-lg shadow p-4 text-center hover:shadow-lg transition">
                        <div class="text-2xl font-bold text-blue-600 mb-2"><?php echo e($category->surveys_count); ?></div>
                        <div class="text-gray-700 font-medium"><?php echo e($category->name); ?></div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
<?php endif; ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\edu-metrics\resources\views\home.blade.php ENDPATH**/ ?>