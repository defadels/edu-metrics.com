

<?php $__env->startSection('title', 'Detail Skala Likert'); ?>
<?php $__env->startSection('page-title', 'Detail Skala Likert'); ?>

<?php $__env->startSection('content'); ?>
<div class="max-w-4xl">
    <div class="bg-white rounded-lg shadow p-6 mb-4">
        <div class="flex justify-between items-start mb-4">
            <div>
                <h3 class="text-2xl font-bold text-gray-900"><?php echo e($likertScale->name); ?></h3>
                <p class="text-sm text-gray-500 mt-1">Range: <?php echo e($likertScale->min_value); ?> - <?php echo e($likertScale->max_value); ?></p>
            </div>
            <div class="flex space-x-2">
                <a href="<?php echo e(route('dashboard.likert-scales.edit', $likertScale)); ?>" class="px-4 py-2 bg-yellow-600 text-white rounded-lg hover:bg-yellow-700">
                    Edit
                </a>
                <form action="<?php echo e(route('dashboard.likert-scales.destroy', $likertScale)); ?>" method="POST" onsubmit="return confirm('Apakah Anda yakin ingin menghapus skala ini?');">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700">
                        Hapus
                    </button>
                </form>
            </div>
        </div>
        
        <div class="mb-4">
            <label class="block text-sm font-medium text-gray-700 mb-2">Label</label>
            <p class="text-gray-900"><?php echo e($likertScale->min_label); ?> - <?php echo e($likertScale->max_label); ?></p>
        </div>
    </div>
    
    <div class="bg-white rounded-lg shadow p-6">
        <h4 class="text-lg font-semibold text-gray-900 mb-4">Opsi Skala (<?php echo e($likertScale->options->count()); ?>)</h4>
        <?php if($likertScale->options->count() > 0): ?>
            <div class="overflow-x-auto">
                <table class="min-w-full divide-y divide-gray-200">
                    <thead class="bg-gray-50">
                        <tr>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Nilai</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Label</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Urutan</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-gray-200">
                        <?php $__currentLoopData = $likertScale->options->sortBy('order'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="px-6 py-4 text-sm text-gray-900"><?php echo e($option->value); ?></td>
                                <td class="px-6 py-4 text-sm text-gray-900"><?php echo e($option->label); ?></td>
                                <td class="px-6 py-4 text-sm text-gray-500"><?php echo e($option->order); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        <?php else: ?>
            <p class="text-gray-500">Belum ada opsi dalam skala ini.</p>
        <?php endif; ?>
    </div>
    
    <div class="mt-4">
        <a href="<?php echo e(route('dashboard.likert-scales.index')); ?>" class="text-blue-600 hover:text-blue-900">← Kembali ke daftar</a>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.dashboard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\edu-metrics\resources\views\dashboard\likert-scales\show.blade.php ENDPATH**/ ?>