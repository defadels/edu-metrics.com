

<?php $__env->startSection('title', 'Detail Survey'); ?>
<?php $__env->startSection('page-title', 'Detail Survey'); ?>

<?php $__env->startSection('content'); ?>
<div class="max-w-4xl">
    <div class="bg-white rounded-lg shadow p-6 mb-4">
        <div class="flex justify-between items-start mb-4">
            <div>
                <h3 class="text-2xl font-bold text-gray-900"><?php echo e($survey->title); ?></h3>
                <p class="text-sm text-gray-500 mt-1">Kategori: <?php echo e($survey->category->name); ?></p>
            </div>
            <div class="flex space-x-2">
                <a href="<?php echo e(route('dashboard.surveys.edit', $survey)); ?>" class="px-4 py-2 bg-yellow-600 text-white rounded-lg hover:bg-yellow-700">
                    Edit
                </a>
                <form action="<?php echo e(route('dashboard.surveys.destroy', $survey)); ?>" method="POST" onsubmit="return confirm('Apakah Anda yakin ingin menghapus survey ini?');">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700">
                        Hapus
                    </button>
                </form>
            </div>
        </div>
        
        <div class="mb-4">
            <label class="block text-sm font-medium text-gray-700 mb-2">Deskripsi</label>
            <p class="text-gray-900"><?php echo e($survey->description ?? '-'); ?></p>
        </div>
        
        <div class="grid grid-cols-2 gap-4 mb-4">
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-2">Tanggal Mulai</label>
                <p class="text-gray-900"><?php echo e($survey->start_date->format('d M Y H:i')); ?></p>
            </div>
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-2">Tanggal Selesai</label>
                <p class="text-gray-900"><?php echo e($survey->end_date->format('d M Y H:i')); ?></p>
            </div>
        </div>
        
        <div class="mb-4">
            <label class="block text-sm font-medium text-gray-700 mb-2">Status</label>
            <div class="flex space-x-4">
                <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full <?php echo e($survey->is_active ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'); ?>">
                    <?php echo e($survey->is_active ? 'Aktif' : 'Tidak Aktif'); ?>

                </span>
                <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full <?php echo e($survey->is_anonymous ? 'bg-blue-100 text-blue-800' : 'bg-gray-100 text-gray-800'); ?>">
                    <?php echo e($survey->is_anonymous ? 'Anonim' : 'Tidak Anonim'); ?>

                </span>
            </div>
        </div>
    </div>
    
    <div class="bg-white rounded-lg shadow p-6 mb-4">
        <div class="flex justify-between items-center mb-4">
            <h4 class="text-lg font-semibold text-gray-900">Pertanyaan (<?php echo e($survey->questions->count()); ?>)</h4>
            <a href="<?php echo e(route('dashboard.questions.create', ['survey_id' => $survey->id])); ?>" class="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700">
                Tambah Pertanyaan
            </a>
        </div>
        <?php if($survey->questions->count() > 0): ?>
            <div class="space-y-4">
                <?php $__currentLoopData = $survey->questions->sortBy('order'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="border border-gray-200 rounded-lg p-4">
                        <div class="flex justify-between items-start">
                            <div class="flex-1">
                                <p class="font-medium text-gray-900"><?php echo e($question->question_text); ?></p>
                                <div class="mt-2 flex space-x-2">
                                    <span class="px-2 py-1 text-xs rounded bg-gray-100 text-gray-800"><?php echo e($question->question_type); ?></span>
                                    <?php if($question->likertScale): ?>
                                        <span class="px-2 py-1 text-xs rounded bg-blue-100 text-blue-800"><?php echo e($question->likertScale->name); ?></span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="ml-4 flex space-x-2">
                                <a href="<?php echo e(route('dashboard.questions.show', $question)); ?>" class="text-blue-600 hover:text-blue-900">Lihat</a>
                                <a href="<?php echo e(route('dashboard.questions.edit', $question)); ?>" class="text-yellow-600 hover:text-yellow-900">Edit</a>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php else: ?>
            <p class="text-gray-500">Belum ada pertanyaan dalam survey ini.</p>
        <?php endif; ?>
    </div>
    
    <div class="mt-4">
        <a href="<?php echo e(route('dashboard.surveys.index')); ?>" class="text-blue-600 hover:text-blue-900">← Kembali ke daftar</a>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.dashboard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\edu-metrics\resources\views\dashboard\surveys\show.blade.php ENDPATH**/ ?>