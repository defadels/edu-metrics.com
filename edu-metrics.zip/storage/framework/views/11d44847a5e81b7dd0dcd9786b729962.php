<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo $__env->yieldContent('title', 'Dashboard'); ?> - <?php echo e(config('app.name', 'Edu Metrics')); ?></title>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
</head>
<body class="bg-gray-50">
    <div class="min-h-screen">
        <!-- Sidebar -->
        <aside class="fixed inset-y-0 left-0 w-64 bg-white border-r border-gray-200">
            <div class="flex flex-col h-full">
                <div class="flex items-center justify-center h-16 border-b border-gray-200">
                    <h1 class="text-xl font-bold text-gray-900"><?php echo e(config('app.name', 'Edu Metrics')); ?></h1>
                </div>
                <nav class="flex-1 px-4 py-4 space-y-2">
                    <a href="<?php echo e(route('dashboard.index')); ?>" class="flex items-center px-4 py-2 text-sm font-medium rounded-lg <?php echo e(request()->routeIs('dashboard.index') ? 'bg-blue-50 text-blue-700' : 'text-gray-700 hover:bg-gray-100'); ?>">
                        <span>Dashboard</span>
                    </a>
                    <a href="<?php echo e(route('dashboard.categories.index')); ?>" class="flex items-center px-4 py-2 text-sm font-medium rounded-lg <?php echo e(request()->routeIs('dashboard.categories.*') ? 'bg-blue-50 text-blue-700' : 'text-gray-700 hover:bg-gray-100'); ?>">
                        <span>Kategori Survey</span>
                    </a>
                    <a href="<?php echo e(route('dashboard.likert-scales.index')); ?>" class="flex items-center px-4 py-2 text-sm font-medium rounded-lg <?php echo e(request()->routeIs('dashboard.likert-scales.*') ? 'bg-blue-50 text-blue-700' : 'text-gray-700 hover:bg-gray-100'); ?>">
                        <span>Skala Likert</span>
                    </a>
                    <a href="<?php echo e(route('dashboard.surveys.index')); ?>" class="flex items-center px-4 py-2 text-sm font-medium rounded-lg <?php echo e(request()->routeIs('dashboard.surveys.*') ? 'bg-blue-50 text-blue-700' : 'text-gray-700 hover:bg-gray-100'); ?>">
                        <span>Survey</span>
                    </a>
                    <a href="<?php echo e(route('dashboard.questions.index')); ?>" class="flex items-center px-4 py-2 text-sm font-medium rounded-lg <?php echo e(request()->routeIs('dashboard.questions.*') ? 'bg-blue-50 text-blue-700' : 'text-gray-700 hover:bg-gray-100'); ?>">
                        <span>Pertanyaan</span>
                    </a>
                </nav>
            </div>
        </aside>

        <!-- Main Content -->
        <div class="pl-64">
            <!-- Top Bar -->
            <header class="bg-white border-b border-gray-200">
                <div class="px-6 py-4">
                    <div class="flex items-center justify-between">
                        <h2 class="text-2xl font-semibold text-gray-900"><?php echo $__env->yieldContent('page-title', 'Dashboard'); ?></h2>
                        <div class="flex items-center space-x-4">
                            <span class="text-sm text-gray-600"><?php echo e(auth()->user()->name ?? 'Guest'); ?></span>
                        </div>
                    </div>
                </div>
            </header>

            <!-- Content -->
            <main class="p-6">
                <?php if(session('success')): ?>
                    <div class="mb-4 p-4 bg-green-50 border border-green-200 text-green-800 rounded-lg">
                        <?php echo e(session('success')); ?>

                    </div>
                <?php endif; ?>

                <?php if(isset($errors) && $errors->any()): ?>
                    <div class="mb-4 p-4 bg-red-50 border border-red-200 text-red-800 rounded-lg">
                        <ul class="list-disc list-inside">
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>

                <?php echo $__env->yieldContent('content'); ?>
            </main>
        </div>
    </div>
</body>
</html>

<?php /**PATH C:\laragon\www\edu-metrics\resources\views\layouts\dashboard.blade.php ENDPATH**/ ?>