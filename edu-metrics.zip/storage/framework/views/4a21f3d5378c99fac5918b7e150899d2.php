

<?php $__env->startSection('title', 'Terima Kasih'); ?>

<?php $__env->startSection('content'); ?>
<div class="max-w-2xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
    <div class="bg-white rounded-lg shadow-lg p-12 text-center">
        <div class="mb-6">
            <svg class="mx-auto h-16 w-16 text-green-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path>
            </svg>
        </div>
        <h1 class="text-3xl font-bold text-gray-900 mb-4">Terima Kasih!</h1>
        <p class="text-lg text-gray-600 mb-2">
            Survey "<strong><?php echo e($survey->title); ?></strong>" telah berhasil Anda submit.
        </p>
        <p class="text-gray-500 mb-8">
            Feedback Anda sangat berharga bagi kami.
        </p>
        <div class="flex space-x-4 justify-center">
            <a href="<?php echo e(route('surveys.index')); ?>" class="bg-blue-600 text-white px-6 py-3 rounded-lg font-semibold hover:bg-blue-700 transition">
                Lihat Survey Lainnya
            </a>
            <a href="<?php echo e(route('home')); ?>" class="bg-gray-200 text-gray-800 px-6 py-3 rounded-lg font-semibold hover:bg-gray-300 transition">
                Kembali ke Beranda
            </a>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\edu-metrics\resources\views\surveys\thank-you.blade.php ENDPATH**/ ?>