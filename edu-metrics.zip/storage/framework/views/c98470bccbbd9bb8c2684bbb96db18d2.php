

<?php $__env->startSection('title', 'Skala Likert'); ?>
<?php $__env->startSection('page-title', 'Skala Likert'); ?>

<?php $__env->startSection('content'); ?>
<div class="mb-4 flex justify-between items-center">
    <h3 class="text-lg font-semibold text-gray-900">Daftar Skala Likert</h3>
    <a href="<?php echo e(route('dashboard.likert-scales.create')); ?>" class="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700">
        Tambah Skala
    </a>
</div>

<div class="bg-white rounded-lg shadow overflow-hidden">
    <table class="min-w-full divide-y divide-gray-200">
        <thead class="bg-gray-50">
            <tr>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Nama</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Range</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Opsi</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Digunakan</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Aksi</th>
            </tr>
        </thead>
        <tbody class="bg-white divide-y divide-gray-200">
            <?php $__empty_1 = true; $__currentLoopData = $scales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $scale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900"><?php echo e($scale->name); ?></td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                        <?php echo e($scale->min_value); ?> - <?php echo e($scale->max_value); ?>

                    </td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500"><?php echo e($scale->options_count); ?></td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500"><?php echo e($scale->questions_count); ?></td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm font-medium space-x-2">
                        <a href="<?php echo e(route('dashboard.likert-scales.show', $scale)); ?>" class="text-blue-600 hover:text-blue-900">Lihat</a>
                        <a href="<?php echo e(route('dashboard.likert-scales.edit', $scale)); ?>" class="text-yellow-600 hover:text-yellow-900">Edit</a>
                        <form action="<?php echo e(route('dashboard.likert-scales.destroy', $scale)); ?>" method="POST" class="inline" onsubmit="return confirm('Apakah Anda yakin ingin menghapus skala ini?');">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="text-red-600 hover:text-red-900">Hapus</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="5" class="px-6 py-4 text-center text-sm text-gray-500">Tidak ada skala Likert.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
    
    <?php if($scales->hasPages()): ?>
        <div class="px-6 py-4 border-t border-gray-200">
            <?php echo e($scales->links()); ?>

        </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.dashboard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\edu-metrics\resources\views\dashboard\likert-scales\index.blade.php ENDPATH**/ ?>