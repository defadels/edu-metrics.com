

<?php $__env->startSection('title', $survey->title); ?>

<?php $__env->startSection('content'); ?>
<div class="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
    <div class="bg-white rounded-lg shadow-lg p-8">
        <!-- Survey Header -->
        <div class="mb-6">
            <div class="flex items-center justify-between mb-4">
                <span class="px-3 py-1 text-sm font-semibold rounded-full bg-blue-100 text-blue-800">
                    <?php echo e($survey->category->name); ?>

                </span>
                <?php if($survey->is_anonymous): ?>
                    <span class="px-3 py-1 text-sm font-semibold rounded-full bg-gray-100 text-gray-800">
                        Survey Anonim
                    </span>
                <?php endif; ?>
            </div>
            <h1 class="text-3xl font-bold text-gray-900 mb-4"><?php echo e($survey->title); ?></h1>
            <?php if($survey->description): ?>
                <p class="text-gray-600 mb-4"><?php echo e($survey->description); ?></p>
            <?php endif; ?>
            <div class="grid grid-cols-2 gap-4 text-sm text-gray-500">
                <div>
                    <span class="font-semibold">Tanggal Mulai:</span>
                    <span><?php echo e($survey->start_date->format('d M Y H:i')); ?></span>
                </div>
                <div>
                    <span class="font-semibold">Tanggal Berakhir:</span>
                    <span><?php echo e($survey->end_date->format('d M Y H:i')); ?></span>
                </div>
                <div>
                    <span class="font-semibold">Jumlah Pertanyaan:</span>
                    <span><?php echo e($survey->questions->count()); ?></span>
                </div>
                <div>
                    <span class="font-semibold">Estimasi Waktu:</span>
                    <span><?php echo e(ceil($survey->questions->count() * 0.5)); ?> menit</span>
                </div>
            </div>
        </div>

        <!-- Warning if already responded -->
        <?php if($hasResponded): ?>
            <div class="mb-6 p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
                <p class="text-yellow-800">
                    <strong>Perhatian:</strong> Anda sudah mengisi survey ini sebelumnya.
                </p>
            </div>
        <?php endif; ?>

        <!-- Questions Preview -->
        <?php if($survey->questions->count() > 0): ?>
            <div class="mb-6">
                <h2 class="text-xl font-semibold text-gray-900 mb-4">Daftar Pertanyaan</h2>
                <div class="space-y-3">
                    <?php $__currentLoopData = $survey->questions->sortBy('order'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="border border-gray-200 rounded-lg p-4">
                            <div class="flex items-start">
                                <span class="flex-shrink-0 w-8 h-8 bg-blue-100 text-blue-800 rounded-full flex items-center justify-center font-semibold text-sm mr-3">
                                    <?php echo e($index + 1); ?>

                                </span>
                                <div class="flex-1">
                                    <p class="text-gray-900 font-medium mb-2"><?php echo e($question->question_text); ?></p>
                                    <div class="flex items-center space-x-2">
                                        <span class="px-2 py-1 text-xs rounded bg-gray-100 text-gray-800">
                                            <?php echo e($question->question_type); ?>

                                        </span>
                                        <?php if($question->is_required): ?>
                                            <span class="px-2 py-1 text-xs rounded bg-red-100 text-red-800">
                                                Wajib
                                            </span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        <?php endif; ?>

        <!-- Action Buttons -->
        <div class="flex space-x-4">
            <a href="<?php echo e(route('surveys.index')); ?>" class="flex-1 text-center bg-gray-200 text-gray-800 px-6 py-3 rounded-lg font-semibold hover:bg-gray-300 transition">
                Kembali
            </a>
            <a href="<?php echo e(route('surveys.start', $survey)); ?>" class="flex-1 text-center bg-blue-600 text-white px-6 py-3 rounded-lg font-semibold hover:bg-blue-700 transition">
                Mulai Mengisi Survey
            </a>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\edu-metrics\resources\views\surveys\show.blade.php ENDPATH**/ ?>