

<?php $__env->startSection('title', 'Daftar Survey'); ?>

<?php $__env->startSection('content'); ?>
<div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
    <div class="mb-8">
        <h1 class="text-3xl font-bold text-gray-900 mb-2">Survey Tersedia</h1>
        <p class="text-gray-600">Pilih survey yang ingin Anda isi</p>
    </div>

    <?php if($surveys->count() > 0): ?>
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
            <?php $__currentLoopData = $surveys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $survey): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="bg-white rounded-lg shadow hover:shadow-lg transition overflow-hidden">
                    <div class="p-6">
                        <div class="flex items-center justify-between mb-4">
                            <span class="px-3 py-1 text-xs font-semibold rounded-full bg-blue-100 text-blue-800">
                                <?php echo e($survey->category->name); ?>

                            </span>
                            <?php if($survey->is_anonymous): ?>
                                <span class="px-3 py-1 text-xs font-semibold rounded-full bg-gray-100 text-gray-800">
                                    Anonim
                                </span>
                            <?php endif; ?>
                        </div>
                        <h3 class="text-xl font-semibold text-gray-900 mb-2"><?php echo e($survey->title); ?></h3>
                        <?php if($survey->description): ?>
                            <p class="text-gray-600 mb-4 line-clamp-3"><?php echo e(Str::limit($survey->description, 120)); ?></p>
                        <?php endif; ?>
                        <div class="space-y-2 mb-4 text-sm text-gray-500">
                            <div class="flex items-center justify-between">
                                <span>Pertanyaan:</span>
                                <span class="font-semibold"><?php echo e($survey->questions_count); ?></span>
                            </div>
                            <div class="flex items-center justify-between">
                                <span>Responses:</span>
                                <span class="font-semibold"><?php echo e($survey->responses_count); ?></span>
                            </div>
                            <div class="flex items-center justify-between">
                                <span>Berakhir:</span>
                                <span class="font-semibold"><?php echo e($survey->end_date->format('d M Y')); ?></span>
                            </div>
                        </div>
                        <a href="<?php echo e(route('surveys.show', $survey)); ?>" class="block w-full text-center bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition">
                            Mulai Survey
                        </a>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <!-- Pagination -->
        <div class="mt-8">
            <?php echo e($surveys->links()); ?>

        </div>
    <?php else: ?>
        <div class="bg-white rounded-lg shadow p-12 text-center">
            <p class="text-gray-500 text-lg">Belum ada survey yang tersedia saat ini.</p>
            <a href="<?php echo e(route('home')); ?>" class="inline-block mt-4 text-blue-600 hover:text-blue-700">
                Kembali ke Beranda
            </a>
        </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\edu-metrics\resources\views\surveys\index.blade.php ENDPATH**/ ?>