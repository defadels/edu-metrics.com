

<?php $__env->startSection('title', 'Isi Survey: ' . $survey->title); ?>

<?php $__env->startSection('content'); ?>
<div class="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
    <div class="bg-white rounded-lg shadow-lg p-8">
        <div class="mb-6">
            <h1 class="text-2xl font-bold text-gray-900 mb-2"><?php echo e($survey->title); ?></h1>
            <p class="text-gray-600">Mohon isi semua pertanyaan yang wajib diisi</p>
        </div>

        <form action="<?php echo e(route('surveys.submit', $survey)); ?>" method="POST" id="surveyForm">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="response_id" value="<?php echo e($activeResponse->id); ?>">

            <div class="space-y-6">
                <?php $__currentLoopData = $survey->questions->sortBy('order'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="border border-gray-200 rounded-lg p-6">
                        <div class="mb-4">
                            <label class="block text-lg font-semibold text-gray-900 mb-2">
                                <?php echo e($index + 1); ?>. <?php echo e($question->question_text); ?>

                                <?php if($question->is_required): ?>
                                    <span class="text-red-500">*</span>
                                <?php endif; ?>
                            </label>
                        </div>

                        <div class="mt-4">
                            <?php if($question->question_type === 'likert'): ?>
                                <?php if($question->likertScale): ?>
                                    <div class="space-y-2">
                                        <?php $__currentLoopData = $question->likertScale->options->sortBy('order'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <label class="flex items-center p-3 border border-gray-200 rounded-lg hover:bg-gray-50 cursor-pointer">
                                                <input type="radio" 
                                                       name="answers[<?php echo e($question->id); ?>][likert_value]" 
                                                       value="<?php echo e($option->value); ?>"
                                                       class="mr-3"
                                                       <?php echo e($question->is_required ? 'required' : ''); ?>>
                                                <span class="text-gray-900"><?php echo e($option->label); ?></span>
                                            </label>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                <?php endif; ?>
                            <?php elseif($question->question_type === 'text'): ?>
                                <textarea 
                                    name="answers[<?php echo e($question->id); ?>][text_value]" 
                                    rows="4"
                                    class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500"
                                    <?php echo e($question->is_required ? 'required' : ''); ?>

                                    placeholder="Tulis jawaban Anda di sini..."></textarea>
                            <?php elseif($question->question_type === 'multiple_choice'): ?>
                                <?php if($question->options->count() > 0): ?>
                                    <div class="space-y-2">
                                        <?php $__currentLoopData = $question->options->sortBy('order'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <label class="flex items-center p-3 border border-gray-200 rounded-lg hover:bg-gray-50 cursor-pointer">
                                                <input type="radio" 
                                                       name="answers[<?php echo e($question->id); ?>][selected_option_id]" 
                                                       value="<?php echo e($option->id); ?>"
                                                       class="mr-3"
                                                       <?php echo e($question->is_required ? 'required' : ''); ?>>
                                                <span class="text-gray-900"><?php echo e($option->option_text); ?></span>
                                            </label>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                <?php else: ?>
                                    <p class="text-gray-500">Belum ada opsi untuk pertanyaan ini.</p>
                                <?php endif; ?>
                            <?php endif; ?>
                        </div>

                        <input type="hidden" name="answers[<?php echo e($question->id); ?>][question_id]" value="<?php echo e($question->id); ?>">
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <div class="mt-8 flex space-x-4">
                <a href="<?php echo e(route('surveys.show', $survey)); ?>" class="flex-1 text-center bg-gray-200 text-gray-800 px-6 py-3 rounded-lg font-semibold hover:bg-gray-300 transition">
                    Batal
                </a>
                <button type="submit" class="flex-1 bg-blue-600 text-white px-6 py-3 rounded-lg font-semibold hover:bg-blue-700 transition">
                    Submit Survey
                </button>
            </div>
        </form>
    </div>
</div>

<script>
document.getElementById('surveyForm').addEventListener('submit', function(e) {
    // Validate required questions
    const requiredQuestions = document.querySelectorAll('[required]');
    let isValid = true;
    
    requiredQuestions.forEach(function(question) {
        if (question.type === 'radio') {
            const name = question.name;
            const checked = document.querySelector(`input[name="${name}"]:checked`);
            if (!checked) {
                isValid = false;
                question.closest('.border').classList.add('border-red-500');
            }
        } else if (!question.value.trim()) {
            isValid = false;
            question.classList.add('border-red-500');
        }
    });

    if (!isValid) {
        e.preventDefault();
        alert('Mohon lengkapi semua pertanyaan yang wajib diisi.');
    }
});
</script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\edu-metrics\resources\views\surveys\fill.blade.php ENDPATH**/ ?>