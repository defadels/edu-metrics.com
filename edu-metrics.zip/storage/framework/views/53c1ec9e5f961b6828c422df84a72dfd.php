

<?php $__env->startSection('title', 'Tambah Pertanyaan'); ?>
<?php $__env->startSection('page-title', 'Tambah Pertanyaan'); ?>

<?php $__env->startSection('content'); ?>
<div class="max-w-2xl">
    <form action="<?php echo e(route('dashboard.questions.store')); ?>" method="POST" class="bg-white rounded-lg shadow p-6">
        <?php echo csrf_field(); ?>
        
        <div class="mb-4">
            <label for="survey_id" class="block text-sm font-medium text-gray-700 mb-2">Survey</label>
            <select name="survey_id" id="survey_id" required class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500">
                <option value="">Pilih Survey</option>
                <?php $__currentLoopData = $surveys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $survey): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($survey->id); ?>" <?php echo e(old('survey_id', $selectedSurvey) == $survey->id ? 'selected' : ''); ?>><?php echo e($survey->title); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <?php $__errorArgs = ['survey_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        
        <div class="mb-4">
            <label for="question_text" class="block text-sm font-medium text-gray-700 mb-2">Teks Pertanyaan</label>
            <textarea name="question_text" id="question_text" rows="3" required class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500"><?php echo e(old('question_text')); ?></textarea>
            <?php $__errorArgs = ['question_text'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        
        <div class="mb-4">
            <label for="question_type" class="block text-sm font-medium text-gray-700 mb-2">Tipe Pertanyaan</label>
            <select name="question_type" id="question_type" required class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500" onchange="toggleLikertScale()">
                <option value="">Pilih Tipe</option>
                <option value="likert" <?php echo e(old('question_type') == 'likert' ? 'selected' : ''); ?>>Likert</option>
                <option value="text" <?php echo e(old('question_type') == 'text' ? 'selected' : ''); ?>>Text</option>
                <option value="multiple_choice" <?php echo e(old('question_type') == 'multiple_choice' ? 'selected' : ''); ?>>Multiple Choice</option>
            </select>
            <?php $__errorArgs = ['question_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        
        <div class="mb-4" id="likert_scale_field" style="display: none;">
            <label for="likert_scale_id" class="block text-sm font-medium text-gray-700 mb-2">Skala Likert</label>
            <select name="likert_scale_id" id="likert_scale_id" class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500">
                <option value="">Pilih Skala Likert</option>
                <?php $__currentLoopData = $likertScales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $scale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($scale->id); ?>" <?php echo e(old('likert_scale_id') == $scale->id ? 'selected' : ''); ?>><?php echo e($scale->name); ?> (<?php echo e($scale->min_value); ?>-<?php echo e($scale->max_value); ?>)</option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <?php $__errorArgs = ['likert_scale_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        
        <div class="mb-4">
            <label for="order" class="block text-sm font-medium text-gray-700 mb-2">Urutan</label>
            <input type="number" name="order" id="order" value="<?php echo e(old('order', 0)); ?>" required min="0" class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500">
            <?php $__errorArgs = ['order'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        
        <div class="mb-4">
            <label class="flex items-center">
                <input type="checkbox" name="is_required" value="1" <?php echo e(old('is_required', true) ? 'checked' : ''); ?> class="rounded border-gray-300 text-blue-600 focus:ring-blue-500">
                <span class="ml-2 text-sm text-gray-700">Wajib diisi</span>
            </label>
        </div>
        
        <div class="flex justify-end space-x-3">
            <a href="<?php echo e(route('dashboard.questions.index')); ?>" class="px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50">
                Batal
            </a>
            <button type="submit" class="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700">
                Simpan
            </button>
        </div>
    </form>
</div>

<script>
function toggleLikertScale() {
    const questionType = document.getElementById('question_type').value;
    const likertField = document.getElementById('likert_scale_field');
    const likertSelect = document.getElementById('likert_scale_id');
    
    if (questionType === 'likert') {
        likertField.style.display = 'block';
        likertSelect.setAttribute('required', 'required');
    } else {
        likertField.style.display = 'none';
        likertSelect.removeAttribute('required');
    }
}

// Initialize on page load
document.addEventListener('DOMContentLoaded', function() {
    toggleLikertScale();
});
</script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.dashboard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\edu-metrics\resources\views\dashboard\questions\create.blade.php ENDPATH**/ ?>