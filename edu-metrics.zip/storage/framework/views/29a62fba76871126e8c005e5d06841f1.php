<button <?php echo e($attributes->merge([
    'type' => 'submit', 
    'class' => 'btn-modern bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700 focus:ring-indigo-500'
])); ?>>
    <?php echo e($slot); ?>

</button>
<?php /**PATH C:\laragon\www\edu-metrics\resources\views/components/primary-button.blade.php ENDPATH**/ ?>