

<?php $__env->startSection('title', 'Detail Pertanyaan'); ?>
<?php $__env->startSection('page-title', 'Detail Pertanyaan'); ?>

<?php $__env->startSection('content'); ?>
<div class="max-w-4xl">
    <div class="bg-white rounded-lg shadow p-6 mb-4">
        <div class="flex justify-between items-start mb-4">
            <div>
                <h3 class="text-2xl font-bold text-gray-900">Pertanyaan</h3>
                <p class="text-sm text-gray-500 mt-1">Survey: <?php echo e($question->survey->title); ?></p>
            </div>
            <div class="flex space-x-2">
                <a href="<?php echo e(route('dashboard.questions.edit', $question)); ?>" class="px-4 py-2 bg-yellow-600 text-white rounded-lg hover:bg-yellow-700">
                    Edit
                </a>
                <form action="<?php echo e(route('dashboard.questions.destroy', $question)); ?>" method="POST" onsubmit="return confirm('Apakah Anda yakin ingin menghapus pertanyaan ini?');">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700">
                        Hapus
                    </button>
                </form>
            </div>
        </div>
        
        <div class="mb-4">
            <label class="block text-sm font-medium text-gray-700 mb-2">Teks Pertanyaan</label>
            <p class="text-gray-900"><?php echo e($question->question_text); ?></p>
        </div>
        
        <div class="grid grid-cols-2 gap-4 mb-4">
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-2">Tipe</label>
                <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-blue-100 text-blue-800">
                    <?php echo e($question->question_type); ?>

                </span>
            </div>
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-2">Urutan</label>
                <p class="text-gray-900"><?php echo e($question->order); ?></p>
            </div>
        </div>
        
        <?php if($question->likertScale): ?>
            <div class="mb-4">
                <label class="block text-sm font-medium text-gray-700 mb-2">Skala Likert</label>
                <p class="text-gray-900"><?php echo e($question->likertScale->name); ?> (<?php echo e($question->likertScale->min_value); ?>-<?php echo e($question->likertScale->max_value); ?>)</p>
            </div>
        <?php endif; ?>
        
        <div class="mb-4">
            <label class="block text-sm font-medium text-gray-700 mb-2">Status</label>
            <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full <?php echo e($question->is_required ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'); ?>">
                <?php echo e($question->is_required ? 'Wajib' : 'Opsional'); ?>

            </span>
        </div>
    </div>
    
    <?php if($question->options->count() > 0): ?>
        <div class="bg-white rounded-lg shadow p-6 mb-4">
            <h4 class="text-lg font-semibold text-gray-900 mb-4">Opsi (<?php echo e($question->options->count()); ?>)</h4>
            <div class="space-y-2">
                <?php $__currentLoopData = $question->options->sortBy('order'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="border border-gray-200 rounded-lg p-3">
                        <p class="text-gray-900"><?php echo e($option->option_text); ?></p>
                        <p class="text-xs text-gray-500 mt-1">Urutan: <?php echo e($option->order); ?></p>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    <?php endif; ?>
    
    <div class="mt-4">
        <a href="<?php echo e(route('dashboard.questions.index')); ?>" class="text-blue-600 hover:text-blue-900">← Kembali ke daftar</a>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.dashboard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\edu-metrics\resources\views\dashboard\questions\show.blade.php ENDPATH**/ ?>